package com.copyfiles;

public interface CopyFile {
	
	public void copyAllFiles(String fileListLocation , String srcDir, String destDir);
	
	public void copyAllFiles(String srcDir, String destDir);
	
	public void copyAFile(String fileLocation, String fileName,  String destDir);
	
	
}
