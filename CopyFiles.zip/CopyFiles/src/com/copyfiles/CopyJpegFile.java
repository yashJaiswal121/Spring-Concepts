package com.copyfiles;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;

public class CopyJpegFile implements CopyFile {
	
	public String fileType = "jpg";
	public Integer progessBar = 0;
	private String srcDir;
	private String destDir;
	
	
	public CopyJpegFile() {}

	public CopyJpegFile(String type,String srcDir, String destDir) {
		super();
		this.srcDir = srcDir;
		this.destDir = destDir;
		this.fileType = type;
	}
	
	

	@Override
	public void copyAllFiles(String srcDir, String destDir) {
		return;
	}

	@Override
	public void copyAFile(String fileLocation, String fileName, String destDir) {
		File source = new File(fileLocation+ "\\" +fileName+"."+fileType);
		File dest = new File(destDir+ "\\" +fileName+"."+fileType);
		try {
		    //FileUtils.copyDirectory(source, dest);
			FileUtils.copyFile(source, dest);
		} catch (IOException e) {
		    e.printStackTrace();
		}
		
	}



	@Override
	public void copyAllFiles(String fileListLocation, String srcDir, String destDir) {
	
		OdsReader odsReader  = new OdsReader();
		File listFile = new File(fileListLocation);
		List<String> fileNames = odsReader.readODS(listFile);
		
		int prev = -1;
		for(String fileName : fileNames) {
			copyAFile(srcDir,fileName,destDir);
			int percentCompleted = ++progessBar / fileNames.size() * 100;
			
			if(percentCompleted != prev)
			System.out.println(percentCompleted);
			
			prev = percentCompleted;
		}
		
	}
	
	
	public static void main(String[] args) {
		CopyJpegFile obj1 = new CopyJpegFile();
		obj1.copyAllFiles("D:\\UserData\\z004ewdb\\Documents\\test.ods","D:\\UserData\\z004ewdb\\Documents\\srcDir","D:\\UserData\\z004ewdb\\Documents\\destDir");
	}

	
}
