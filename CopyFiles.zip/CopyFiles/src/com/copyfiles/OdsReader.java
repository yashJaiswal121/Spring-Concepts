package com.copyfiles;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jopendocument.dom.spreadsheet.MutableCell;
import org.jopendocument.dom.spreadsheet.Sheet;
import org.jopendocument.dom.spreadsheet.SpreadSheet;

public class OdsReader {
	  public List<String> readODS(File file)
	  {
	    SpreadSheet spreadsheet;
	    List<String> readFileNames = new ArrayList<>();
	    try {
	         //Getting the 0th sheet for manipulation| pass sheet name as string

	    	System.out.println("-----------OdsReader start --------------------");
	         spreadsheet = SpreadSheet.createFromFile(file);

	         //Get row count and column count
	         int nColCount = spreadsheet.getSheet(0).getColumnCount();
	         int nRowCount = spreadsheet.getSheet(0).getRowCount();

	         System.out.println("Rows :"+nRowCount);
	         System.out.println("Cols :"+nColCount);
	         //Iterating through each row of the selected sheet
	         MutableCell cell = null;
	         for(int nRowIndex = 0; nRowIndex < 2; nRowIndex++)
	         {
	           //Iterating through each column
	           for(int nColIndex = 0; nColIndex < 1; nColIndex++)
	           {
	             cell = spreadsheet.getSheet(0).getCellAt(nColIndex, nRowIndex);
	             System.out.print(cell.getValue()+ " ");
	             readFileNames.add("8V4B"+(String) cell.getValue().toString());
	            }
	            
	          }
	         
	         System.out.println("-----------OdsReader End --------------------");

	        } catch (IOException e) {
	          e.printStackTrace();
	        }
	    
	    return readFileNames;
	  }
	
	}
